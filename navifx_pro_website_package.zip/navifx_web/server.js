'use strict';
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const API_BASE = 'https://otcharts.com';

app.disable('x-powered-by');
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.get('/api/health', (_req, res) => {
  if (!process.env.OTCHARTS_API_KEY) return res.status(503).json({ error: 'لم يتم ضبط OTCHARTS_API_KEY في إعدادات الخادم.' });
  res.json({ ok: true, provider: 'OTCharts', keyConfigured: true });
});

// A restricted same-origin proxy. The API key never reaches browser JavaScript.
app.get('/api/otc', async (req, res) => {
  const key = process.env.OTCHARTS_API_KEY;
  if (!key) return res.status(503).json({ error: 'مفتاح OTCharts غير مضبوط على الخادم.' });
  const target = String(req.query.path || '');
  if (!/^\/v1\/(venues|usage|symbols|candles|stream)(\?.*)?$/.test(target)) {
    return res.status(400).json({ error: 'مسار API غير مسموح.' });
  }
  const isStream = target.startsWith('/v1/stream?');
  const controller = new AbortController();
  res.on('close', () => controller.abort());
  try {
    const upstream = await fetch(API_BASE + target, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${key}`,
        'Accept': isStream ? 'text/event-stream' : 'application/json',
        'User-Agent': 'NaviFX-Pro/1.0'
      },
      signal: controller.signal
    });
    res.status(upstream.status);
    if (isStream && upstream.ok && upstream.body) {
      res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', 'Connection': 'keep-alive', 'X-Accel-Buffering': 'no' });
      const reader = upstream.body.getReader();
      try {
        while (true) {
          const { value, done } = await reader.read();
          if (done || res.destroyed) break;
          if (!res.write(Buffer.from(value))) await new Promise(resolve => res.once('drain', resolve));
        }
      } finally { try { reader.releaseLock(); } catch (_) {} }
      return res.end();
    }
    const body = await upstream.text();
    res.type('application/json').send(body);
  } catch (err) {
    if (res.destroyed) return;
    res.status(502).json({ error: 'تعذر الوصول إلى OTCharts من الخادم.', detail: err.name === 'AbortError' ? 'انقطع الطلب.' : err.message });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, '0.0.0.0', () => console.log(`NaviFX Pro listening on ${PORT}`));
